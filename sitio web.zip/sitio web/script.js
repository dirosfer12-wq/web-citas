document.addEventListener("DOMContentLoaded", () => {
    const formulario = document.querySelector(".booking-form");

    // Credenciales de Telegram configuradas
    const TELEGRAM_TOKEN = "8946529974:AAHSVcKL50aghJuYeMQwAy2iViW2lx0KbSY";
    const CHAT_ID = "6553664665";

    formulario.addEventListener("submit", async (evento) => {
        evento.preventDefault(); // Evita que la página se recargue

        // 1. Leer los campos del formulario
        const nombre   = document.getElementById("name").value.trim();
        const email    = document.getElementById("email").value.trim();
        const fecha    = document.getElementById("date").value;
        const hora     = document.getElementById("time").value;
        const notas    = document.getElementById("notes").value.trim() || "Ninguna";

        // 2. Crear una "llave única" para la cita (Ejemplo: "2026-05-30@14:00")
        const horarioLlave = `${fecha}@${hora}`;

        // 3. Obtener la lista de citas ya agendadas de la memoria del navegador
        // Si no hay ninguna, empezamos con una lista vacía []
        let citasAgendadas = JSON.parse(localStorage.getItem("citas_voltex")) || [];

        // 4. CONTROL DE DUPLICADOS: Verificar si el horario ya existe en la lista
        if (citasAgendadas.includes(horarioLlave)) {
            alert("❌ Lo sentimos, este horario ya está reservado. Por favor, elige otra fecha u hora.");
            return; // Detiene el código aquí y NO envía nada a Telegram
        }

        // Si el horario está libre, procedemos a enviar a Telegram
        const boton = formulario.querySelector(".btn-submit");
        boton.textContent = "Enviando...";
        boton.disabled = true;

        // Formatear fecha a dd/mm/aaaa para el mensaje
        const [anio, mes, dia] = fecha.split("-");
        const fechaLegible = `${dia}/${mes}/${anio}`;

        const mensajeText = 
            `🤖 *¡NUEVA CITA RECIBIDA!*\n` +
            `────────────────────\n` +
            `👤 *Cliente:* ${nombre}\n` +
            `📧 *Correo:* ${email}\n` +
            `📅 *Fecha:* ${fechaLegible}\n` +
            `⏰ *Hora:* ${hora}\n` +
            `📝 *Notas:* ${notas}\n` +
            `────────────────────`;

        const url = `https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`;

        try {
            const respuesta = await fetch(url, {
                method: "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify({
                    chat_id: CHAT_ID,
                    text: mensajeText,
                    parse_mode: "Markdown"
                })
            });

            if (respuesta.ok) {
                // 5. GUARDAR EN MEMORIA: Como la cita fue exitosa, guardamos el horario
                citasAgendadas.push(horarioLlave);
                localStorage.setItem("citas_voltex", JSON.stringify(citasAgendadas));

                alert("¡Cita enviada con éxito al sistema!");
                formulario.reset(); 
            } else {
                alert("Hubo un problema. Asegúrate de haber presionado 'Iniciar' en tu bot de Telegram.");
            }
        } catch (error) {
            alert("Error de conexión. Revisa tu internet.");
        } finally {
            boton.textContent = "Confirmar Cita";
            boton.disabled = false;
        }
    });
});